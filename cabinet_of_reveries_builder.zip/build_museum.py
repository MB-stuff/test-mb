#!/usr/bin/env python3
"""Download 100 CC0 museum images, sorted into 10 themed galleries."""
import argparse, csv, hashlib, html, io, json, re, sys, time, unicodedata, zipfile
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from PIL import Image, ImageOps

# Each slot is a curatorial target; alternatives are selected from the same theme.
ROOMS = {
'01_japan_dreams': ['Hokusai Great Wave','Hiroshige sudden shower','Hiroshige moon','Hokusai red Fuji','Hiroshige snow','Hasui moon','Shunsho courtesan','Utamaro woman','Japanese woodblock night','Japanese woodblock waterfall'],
'02_night_and_melancholy': ['Whistler nocturne','Friedrich moon','John Atkinson Grimshaw night','Edvard Munch night','Odilon Redon night','George Inness sunset','Albert Pinkham Ryder moonlight','Homer moonlight','moonlight landscape','twilight landscape'],
'03_lost_cities': ['Piranesi ruins','Charles Meryon Paris','Canaletto Venice','John Ruskin architecture','Eugene Atget Paris','Gustave Le Gray architecture','Abbott architecture photograph','ancient Rome ruins','Venice canal','cathedral interior'],
'04_faces_of_time': ['Julia Margaret Cameron portrait','Nadar portrait','Gertrude Kasebier portrait','Alfred Stieglitz portrait','Edward Steichen portrait','Rembrandt self portrait','John Singer Sargent portrait','James McNeill Whistler portrait','Daguerreotype portrait','Cecilia Beaux portrait'],
'05_strange_worlds': ['Odilon Redon eye','William Blake angel','Gustave Dore illustration','Giovanni Battista Piranesi prison','Max Klinger fantasy','James Ensor masks','Goya caprichos','Ferdinand Hodler dream','symbolist lithograph','mythological monster'],
'06_sacred_and_ancient': ['Byzantine icon','Russian icon','Madonna and Child','medieval illuminated manuscript','Albrecht Durer angel','Buddhist mandala','Egyptian funerary painting','Persian manuscript painting','Gothic altarpiece','stained glass angel'],
'07_wild_earth': ['Caspar David Friedrich landscape','Albert Bierstadt mountains','Thomas Cole landscape','Frederic Edwin Church landscape','John Constable cloud','Claude Monet coast','Winslow Homer ocean','Gustave Courbet sea','J M W Turner landscape','Camille Corot forest'],
'08_paper_universes': ['Audubon bird','Maria Sibylla Merian insect','botanical illustration flower','Japanese bird flower print','scientific illustration plant','antique world map','celestial map','natural history shell','Ernst Haeckel','herbarium botanical'],
'09_modern_life': ['Henri de Toulouse-Lautrec poster','Alphonse Mucha poster','Charles Rennie Mackintosh design','El Lissitzky','Wassily Kandinsky abstract','Paul Klee drawing','Fernand Leger','Piet Mondrian','Art Nouveau poster','Japanese modern poster'],
'10_quiet_objects': ['Chardin still life','Paul Cezanne still life','Vincent van Gogh still life','Dutch still life flowers','Japanese ceramic tea bowl','Chinese porcelain vase','Persian textile pattern','Art Nouveau glass vase','William Morris textile','antique clock'],
}
FALLBACK = {
'01_japan_dreams':['Hiroshige','Hokusai','Japanese woodblock print'],
'02_night_and_melancholy':['moonlight','nocturne','twilight landscape'],
'03_lost_cities':['architectural print','city street photograph','Venice architecture'],
'04_faces_of_time':['portrait photograph','daguerreotype','portrait painting'],
'05_strange_worlds':['Odilon Redon','William Blake','mythology print'],
'06_sacred_and_ancient':['illuminated manuscript','religious painting','icon'],
'07_wild_earth':['landscape painting','mountain landscape','seascape'],
'08_paper_universes':['botanical print','bird print','natural history'],
'09_modern_life':['poster','art nouveau','abstract painting'],
'10_quiet_objects':['still life','ceramic vessel','textile pattern'],
}
AIC='https://api.artic.edu/api/v1/artworks/search'
CMA='https://openaccess-api.clevelandart.org/api/artworks/'
UA='MuseumCollectionBuilder/1.0 (educational personal web museum; open access images)'
last={}; cache={}

def fetch(url, service):
    # Respect Chicago's published one-request-per-second guideline, including images.
    for attempt in range(3):
        elapsed=time.monotonic()-last.get(service,0)
        if elapsed<1.1: time.sleep(1.1-elapsed)
        last[service]=time.monotonic()
        try:
            with urlopen(Request(url,headers={'User-Agent':UA,'Accept':'*/*'}),timeout=25) as r:
                return r.read()
        except Exception as e:
            if attempt==2: raise
            time.sleep(2**attempt)

def query(service, phrase):
    key=(service,phrase)
    if key in cache: return cache[key]
    if service=='aic':
        params={'q':phrase,'limit':35,'query[term][is_public_domain]':'true','fields':'id,title,artist_display,date_display,image_id,is_public_domain,artwork_type_title'}
        response=json.loads(fetch(AIC+'?'+urlencode(params),service)); result=[]
        for a in response.get('data',[]):
            if a.get('is_public_domain') is not True or not a.get('image_id'): continue
            result.append(dict(id='aic:'+str(a['id']),title=a.get('title','Untitled'),artist=a.get('artist_display',''),date=a.get('date_display',''),source='Art Institute of Chicago',license='CC0',url='https://www.artic.edu/artworks/'+str(a['id']),image='https://www.artic.edu/iiif/2/'+a['image_id']+'/full/843,/0/default.jpg'))
    else:
        params={'q':phrase,'limit':35,'cc0':'','has_image':1}
        response=json.loads(fetch(CMA+'?'+urlencode(params),service)); result=[]
        for a in response.get('data',[]):
            image=((a.get('images') or {}).get('web') or {}).get('url')
            if a.get('share_license_status')!='CC0' or not image: continue
            artist='; '.join(c.get('description','') for c in (a.get('creators') or []))
            result.append(dict(id='cma:'+str(a['id']),title=a.get('title','Untitled'),artist=artist,date=a.get('creation_date',''),source='Cleveland Museum of Art',license='CC0',url=a.get('url') or 'https://www.clevelandart.org/art/'+a['accession_number'],image=image))
    cache[key]=result; return result

def slug(s):
    s=unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+','-',s).strip('-')[:65] or 'untitled'

def words(s): return set(re.findall(r'[a-z0-9]+',s.lower()))-{'the','and','of','a','in','at','by'}

def select(phrase, room, seen, hashes, target, services):
    for term in [phrase]+FALLBACK[room]:
        for service in services:
            try: candidates=query(service,term)
            except Exception as e:
                print(f'  {service} search failed: {e}',flush=True); continue
            ranked=sorted(candidates,key=lambda a:len(words(term)&words(a['title']+' '+a['artist'])),reverse=True)
            for a in ranked:
                if a['id'] in seen: continue
                titlekey=slug(a['title'])+'|'+slug(a['artist'])[:20]
                if titlekey in seen: continue
                try:
                    raw=fetch(a['image'],service)
                    with Image.open(io.BytesIO(raw)) as original:
                        im=ImageOps.exif_transpose(original).convert('RGB')
                        if min(im.size)<300: continue
                        im.thumbnail((1200,1200),Image.Resampling.LANCZOS)
                        digest=hashlib.sha256(im.tobytes()).hexdigest()
                        if digest in hashes: continue
                        filename=f'{target:02d}_{slug(a["title"])}_{a["id"].replace(":","-")}.webp'
                        path=Path(room)/filename
                        yield a,path,im,digest,titlekey
                except Exception as e:
                    print(f'  image skipped: {e}',flush=True)

def gallery(root, records):
    chunks=['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Cabinet of Reveries</title><style>body{background:#151618;color:#e7dfce;font:16px Georgia,serif;margin:5vw}h1{font-size:clamp(36px,6vw,78px);font-weight:normal}h2{margin-top:3rem;font-weight:normal}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:24px}figure{margin:0}img{width:100%;height:240px;object-fit:contain;background:#222}figcaption{padding-top:8px}small{color:#a8a29a}a{color:inherit}</style><h1>Cabinet of Reveries</h1><p>100 open-access images · ten galleries</p>']
    for room in ROOMS:
        chunks.append('<h2>'+html.escape(room[3:].replace('_',' ').title())+'</h2><div class="grid">')
        for r in records:
            if r['room']!=room: continue
            esc=lambda s:html.escape(str(s or ''),quote=True)
            chunks.append(f'<figure><a href="{esc(r["file"])}"><img loading="lazy" src="{esc(r["file"])}" alt="{esc(r["title"])}"></a><figcaption><a href="{esc(r["url"])}">{esc(r["title"])}</a><br><small>{esc(r["artist"])} · {esc(r["date"])}</small></figcaption></figure>')
        chunks.append('</div>')
    chunks.append('</html>'); (root/'gallery.html').write_text('\n'.join(chunks),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',default='cabinet_of_reveries',help='Output directory'); args=ap.parse_args()
    root=Path(args.output).resolve(); root.mkdir(parents=True,exist_ok=True)
    manifest=root/'manifest.json'; records=json.loads(manifest.read_text(encoding='utf-8')) if manifest.exists() else []
    records=[r for r in records if (root/r['file']).is_file()]
    seen={k for r in records for k in (r['id'],slug(r['title'])+'|'+slug(r['artist'])[:20])}; hashes={r['hash'] for r in records}
    for room,phrases in ROOMS.items():
        (root/room).mkdir(exist_ok=True)
        for i,phrase in enumerate(phrases,1):
            if any(r['room']==room and r['slot']==i for r in records): continue
            print(f'{room} {i}/10: {phrase}',flush=True)
            services=['aic','cma'] if i%2 else ['cma','aic']
            for a,path,im,digest,titlekey in select(phrase,room,seen,hashes,i,services):
                im.save(root/path,'WEBP',quality=88,method=4)
                seen.update((a['id'],titlekey)); hashes.add(digest)
                records.append(dict(a,room=room,slot=i,target=phrase,file=path.as_posix(),hash=digest))
                manifest.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
                print(f'  ✓ {a["title"]} ({a["source"]})',flush=True); break
            else: print('  No matching image yet; rerun to retry.',flush=True)
    records.sort(key=lambda r:(r['room'],r['slot']))
    manifest.write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
    with (root/'credits.csv').open('w',encoding='utf-8-sig',newline='') as f:
        fields=['file','title','artist','date','source','license','url','image','target']; w=csv.DictWriter(f,fields,extrasaction='ignore'); w.writeheader(); w.writerows(records)
    gallery(root,records)
    (root/'LICENSES.txt').write_text('Each included image was checked for CC0 status via the source museum API. See credits.csv for individual sources.\nArt Institute of Chicago: https://www.artic.edu/open-access/open-access-images\nCleveland Museum of Art: https://www.clevelandart.org/open-access\n',encoding='utf-8')
    count=len(records)
    if count!=100:
        print(f'Only {count}/100 images acquired. Run the same command again to resume; no complete ZIP created.',file=sys.stderr); return 1
    archive=root.parent/(root.name+'.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for r in records: z.write(root/r['file'],r['file'])
        for name in ('manifest.json','credits.csv','gallery.html','LICENSES.txt'): z.write(root/name,name)
    print(f'Complete: {archive} (100 images)'); return 0

if __name__=='__main__': sys.exit(main())
