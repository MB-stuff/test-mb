CABINET OF REVERIES — сборщик веб-музея

Это не готовый архив изображений: программа загружает их из двух открытых
музейных коллекций на вашем компьютере. Нужны Python 3.9+ и интернет.

Windows:
  py -m pip install Pillow
  py build_museum.py

Linux / macOS:
  python3 -m pip install Pillow
  python3 build_museum.py

Если Linux запрещает установку в системный Python:
  python3 -m venv .venv
  .venv/bin/python -m pip install Pillow
  .venv/bin/python build_museum.py

Итог: кабинет cabinet_of_reveries/ и cabinet_of_reveries.zip.
100 WebP (10 папок по 10), credits.csv, manifest.json, gallery.html.
Если часть файлов не скачалась, повторите ту же команду: успешные загрузки
сохраняются, а недостающие повторяются. ZIP создаётся только при 100 работах.

Подборка составлена из 100 тематических запросов, а не проверенных отдельных
объектов. Если точное произведение недоступно под CC0, скрипт выбирает другую
работу по теме. Внешние API и сеть могут влиять на результат.
