# Источники / SOURCES — Noir & Retrofuture Hotel Research Pack

## Важно
PNG и SVG в этом архиве — **авторские схематические интерпретации для геймдизайна**, НЕ точные копии исторических поэтажных планов. Геометрия, связи комнат и подписи переработаны и частично вымышлены. Используй как концепты для проектирования уровня, но не называй их подлинными историческими чертежами.

Оригинальные архивные изображения доступны по ссылкам ниже. В скачанный ZIP они не включены: архивные TIFF весом до 400 МБ и с неопределённым статусом авторских прав, поэтому их следует получать непосредственно в архиве; в этом наборе нет чужих полноразмерных сканов.

## 01 — Noir / Riviera Hotel & Casino, Las Vegas (1954)
- Первый этаж (ground floor plan), 28 июля 1954: https://special.library.unlv.edu/ark:/62930/d1n873c86
- Подвал, антресоль и крыша, 28 июля 1954: https://special.library.unlv.edu/ark:/62930/d1833nb96
- Пентхаус, 28 июля 1954: https://special.library.unlv.edu/ark:/62930/d1cv4c53n
- Фасад Riviera, фото 1957 года (CC BY 2.0): https://commons.wikimedia.org/wiki/File:Riviera_hotel_(1957).jpg

## 02 — Noir / Plaza Hotel, New York (1952)
- План 10-го этажа: https://texashistory.unt.edu/ark:/67531/metapth1343312/

## 03 — Retrofuture / International Hotel, Las Vegas (1967–1968)
- Типовой этаж, 20 июля 1967: https://special.library.unlv.edu/ark:/62930/d1930p77g
- Главный план южной половины 1-го этажа, 5 августа 1968: https://special.library.unlv.edu/ark:/62930/d1cv4c506
- Второй этаж, секция C, 5 августа 1968: https://special.library.unlv.edu/ark:/62930/d16688z15
- Второй этаж, секция D, 5 августа 1968: https://special.library.unlv.edu/ark:/62930/d12f7k46b
- Первый этаж, секция G: https://special.library.unlv.edu/ark:/62930/d1tx35k7t
- Историческая открытка (статус PD в США по Commons): https://commons.wikimedia.org/wiki/File:International_Hotel_postcard.jpg

## 04 — Retrofuture / прочие референсы
- Hotel Tambaú — круговой план (проект более поздний, чем 1950-е): https://vitruvius.com.br/index.php/revistas/read/arquitextos/18.206/6627
- Архив гостиничных чертежей (с пометками лицензий для каждого плана): https://roark.archi/plans/hotels
- Motel 1950s, Library of Congress: https://www.loc.gov/item/95859456/

## Лицензирование
- SVG и PNG внутри архива созданы для данного проекта; они не являются строительной документацией и не претендуют на историческую точность.
- Подлинные сканы UNLV имеют пометку Copyright Not Evaluated; разрешение на воспроизведение/публикацию может потребоваться отдельно.
- Подлинные фотографии и иные изображения по ссылкам могут иметь отдельные права и требования атрибуции.
